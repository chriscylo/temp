package com.example.assignment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeService {

    final static String FIRST_NAME_CSV = "src/main/resources/First_Name.csv";
    final static String SALARY_CSV = "src/main/resources/Salary.csv";

    final static String EMPLOYEE_TYPE_CSV = "src/main/resources/Employee_type.csv";
    final static String EMPLOYEE_Title = "src/main/resources/Employee_Title.csv";

    final static String XML_FILE_PATH = "src/main/resources/Interview_EmployeeTitle.xml";


    @Autowired
    private EmployeeRepository employeeRepository;


    public void getEmployeeNames() throws IOException, JSONException {
        JSONArray dataList = getRestData();
        JSONArray updatedNamesList = new JSONArray();
        for (int i = 0; i < dataList.length(); i++) {
            JSONObject itemArr = (JSONObject) dataList.get(i);
            String name = itemArr.get("employee_name").toString().split(" ")[0];
            JSONObject temp = new JSONObject();
            temp.put("firstName", name);
            updatedNamesList.put(temp);
        }
        CsvUtility.doProcess(updatedNamesList, FIRST_NAME_CSV);

    }


    public void getEmployeeSalary() throws IOException, JSONException {
        JSONArray dataList = getRestData();
        JSONArray updatedNamesList = new JSONArray();
        for (int i = 0; i < dataList.length(); i++) {
            JSONObject itemArr = (JSONObject) dataList.get(i);
            String salary = itemArr.get("employee_name").toString();
            JSONObject temp = new JSONObject();
            temp.put("Salary", salary);
            updatedNamesList.put(temp);
        }
        CsvUtility.doProcess(updatedNamesList, SALARY_CSV);

    }

    public void getEmployeeTypes() throws JSONException, IOException {
        JSONArray dataList = getRestData();
        List<Employee> listEmployees = employeeRepository.findAll();
        for (int i = 0; i < dataList.length(); i++) {
            JSONObject itemArr = (JSONObject) dataList.get(i);
            int id = (int) itemArr.get("id");
            Employee emp = getEmp(listEmployees, id);
            String type = "NA";
            if (emp != null) {
                type = emp.getEmployee_type();
            }
            itemArr.put("employee_type", type);
        }
        CsvUtility.doProcess(dataList, EMPLOYEE_TYPE_CSV);


    }

    public void getEmployeeTitle() throws JSONException, IOException {

        JSONArray dataList = getRestData();
        NodeList nodeList = XmlUtiliy.doProcess(XML_FILE_PATH);
        List<Employee> empList = new ArrayList<Employee>();

        for (int i = 0; i < nodeList.getLength(); i++) {
            empList.add(getEmployee(nodeList.item(i)));
        }
        for (int i = 0; i < dataList.length(); i++) {
            JSONObject itemArr = (JSONObject) dataList.get(i);
            int id = (int) itemArr.get("id");
            Employee emp = getEmp(empList, id);
            String title = "NA";
            if (emp != null) {
                title = emp.getEmployee_title();
            }
            itemArr.put("employee_title", title);
        }
        CsvUtility.doProcess(dataList, EMPLOYEE_Title);


    }


    private static Employee getEmployee(Node node) {
        Employee emp = new Employee();
        if (node.getNodeType() == Node.ELEMENT_NODE) {
            Element element = (Element) node;
            emp.setEmployee_age(Integer.parseInt(getTagValue("employee_age", element)));
            emp.setEmployee_name((getTagValue("employee_name", element)));
            emp.setEmployee_salary(Integer.parseInt(getTagValue("employee_salary", element)));
            emp.setEmployee_title((getTagValue("employee_title", element)));

            emp.setId(Integer.parseInt(getTagValue("id", element)));
        }
        return emp;
    }


    private static String getTagValue(String tag, Element element) {
        NodeList nodeList = element.getElementsByTagName(tag).item(0).getChildNodes();
        Node node = nodeList.item(0);
        return node.getNodeValue();
    }


    private Employee getEmp(List<Employee> list, int id) {

        List<Employee> result = list.stream()
                .filter(item -> item.id == id)
                .collect(Collectors.toList());

        return (result.size() > 0) ? result.get(0) : null;
    }

    private JSONArray getRestData() throws JSONException {
        final String uri = "https://dummy.restapiexample.com/api/v1/employees";
        RestTemplate restTemplate = new RestTemplate();
        String result = restTemplate.getForObject(uri, String.class);
        JSONObject obj = new JSONObject(result);
        JSONArray dataList = obj.getJSONArray("data");
        return dataList;
    }

}
