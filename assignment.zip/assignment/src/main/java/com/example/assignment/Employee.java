package com.example.assignment;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "employee")
public class Employee{
    public int id;
    public String employee_name;
    public int employee_salary;
    public int employee_age;
    public String profile_image;
    public String employee_title;

    public String employee_type;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public int getId() {
        return id;
    }

    public String getEmployee_type() {
        return employee_type;
    }

    public String getEmployee_title() {
        return employee_title;
    }

    public void setEmployee_title(String employee_title) {
        this.employee_title = employee_title;
    }

    public void setEmployee_type(String employee_type) {
        this.employee_type = employee_type;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmployee_name() {
        return employee_name;
    }

    public void setEmployee_name(String employee_name) {
        this.employee_name = employee_name;
    }

    public int getEmployee_salary() {
        return employee_salary;
    }

    public void setEmployee_salary(int employee_salary) {
        this.employee_salary = employee_salary;
    }

    public int getEmployee_age() {
        return employee_age;
    }

    public void setEmployee_age(int employee_age) {
        this.employee_age = employee_age;
    }

    public String getProfile_image() {
        return profile_image;
    }

    public void setProfile_image(String profile_image) {
        this.profile_image = profile_image;
    }




}

class Root{
    public String status;
    public List<Employee> data;
    public String message;
}


