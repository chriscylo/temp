package com.example.assignment;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
public class EmployeeController {

   @Autowired
    EmployeeService employeeService;
    @GetMapping("rest-api/employee-names")
    private void getEmployeeNames() throws IOException, JSONException {
        employeeService.getEmployeeNames();
    }

    @GetMapping("rest-api/employee-salary")
    private void getEmployeeSalary() throws IOException, JSONException {
        employeeService.getEmployeeSalary();
    }

    @GetMapping("ms-sql/employee-types")
    private void getEmployeeTypes() throws JSONException, IOException {
        employeeService.getEmployeeTypes();
    }

    @GetMapping("xml/title")
    private void getEmployeeTitle() throws JSONException, IOException {
        employeeService.getEmployeeTitle();
    }


}
