mvn clean
mvn install
it can be run as simple spring boot application


There are four end points and can be tested from postman:

http://localhost:8080/rest-api/employee-names
http://localhost:8080/rest-api/employee-salary
http://localhost:8080/ms-sql/employee-types
http://localhost:8080/xml/title


Interview_EmployeeTitle.xml and Interview_InitialLoadScript.sql
are two files inside inside resources folder taken as part of xml creation and sql insertion

output will be different csv will be placed inside resources foldr based on end point being hit.


few csv generated after hitting api from postman are inside resources folder.


if url needs to updated it can be done in employee service Line 138

final String uri = "https://dummy.restapiexample.com/api/v1/employees";
